﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

    public class SessionData
    {
        public const string 登录用户 = "LoginUser";
        public const string 登录用户名称 = "LoginUserName";
        /// <summary>
        /// 角色主要有：教师/学生/管理员
        /// </summary>
        public const string 用户类别 = "LoginUserType";

    }